class TechDataModel {
  final String name;
  TechDataModel(this.name);
}
