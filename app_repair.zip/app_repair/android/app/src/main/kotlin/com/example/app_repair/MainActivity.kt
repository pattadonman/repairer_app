package com.example.app_repair

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
