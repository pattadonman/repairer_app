// main.dart
import 'dart:convert';
import 'package:http/http.dart' as http;

import 'dart:async';
import 'package:flutter/material.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:projec1234/dataManagement.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      //title: 'Kindacode.com',
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {


  @override
  Widget build(BuildContext context) {


    dataManagement textData = new dataManagement();
    String nameJsonSelect = textData.get_nameJsonSelect();
    String _contentSelect = "";

    // Find the Documents path
    Future<String> _getDirPath() async {
      final _dir = await getApplicationDocumentsDirectory();
      return _dir.path;
    }

    Future<void> _readDataSelect() async {
      //print("_readData");
      final _dirPath = await _getDirPath();
      final _myFile = File('$_dirPath/$nameJsonSelect.json');
      final _data = await _myFile.readAsString(encoding: utf8);
      setState(() {
        _contentSelect = _data;
      });
      print("=======readJsonDataSelect============"+_contentSelect);
    }

    //=======CRUD========Create, read, update and delete===============
    print("=======CRUD========Create, read, update and delete===============");
      //delete value table :: nameTable,id,valueId
      textData.setDeleteDataMySql("role", "id", "10");
      //update value table :: nameTable,typeField,valueField,conditionField,conditionValueField
      textData.setUpdateDataMySql("role", "id_role", "13", "id", "2");
      //show to read value table :: nameTable , typeSelect,conditiionField,conditonValueField
      textData.setSelectDataMySql("role", "id_data", "id", "1");
      //show data select from setSelectDataMySql
      _readDataSelect();
      //insert User to value table :: id, firstname, lastname, type, address, phone, user, password, avatar, lat, lng
      textData.insertUserTable("id", "23", "34", "44", "55", "66", "77", "88", "55", "66", "77");
    //insert SubmitService_customer to value table :: id, firstname, lastname, type, address, phone, user, password, avatar, lat, lng
    textData.insertSubmitService_customerTable("4", "1", "2", "3", "4", "5", "7", "8", "10", "8", "9");

    //print(textData.setSelectDataMySql("customer", "email", "id", "1"));
    //print (textData.ansSelect);

      //print(textData.returnSelectData());
      //print("===========================");
      //_readDataSelect();
      //print("_contectDataSelect :: $_contentSelect");

      //=======================================
      //textData.insertUserTable("12","2","3","4","5","6","7","8","9","10","11");
     //textData.insertSubmitService_customerTable("2", "3", "4", "5", "0000-00-00", "7", "8", "9", "10", "11", "12");
    print("===================================End============================");
    //===================================End============================
    return Scaffold(

    );
  }
}


