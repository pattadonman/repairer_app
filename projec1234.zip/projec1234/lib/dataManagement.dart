import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:crypto/crypto.dart';



class dataManagement {
  // This will be displayed on the screen

  // data
  String _content = "";
  String nameJson = "jsonData";
  String nameLocalHost = "10.0.2.2";
  String folderLocalHost = "repairer_data";

  // list data from mysql
  String id = "2";
  String email = "treeoaknumber1@gmail.com";
  String password = "xxx";
  String id_role = "2";
  String apple_id = "nonValue";
  String phone_number = "nonValue";
  String social_network = "nonValue";
  String id_data = "3";
  String first_name = "nonValue";
  String last_name = "nonValue";
  String birthday = "1999-05-13";
  String gender = "nonValue";
  String nickname = "nonValue";
  String education = "nonValue";
  String campaign_use = "nonValue";
  String favourite_color = "nonValue";
  String number_car_door = "4";
  String car_type = "nonValue";
  String age_children = "15";
  String marital_status = "nonValue";
  String enterpire = "nonValue";
  String pet_ownership = "nonValue";
  String age = "35";
  String property_type = "nonValue";
  String ethnicity = "nonValue";
  String number_children = "1";
  String location_qps_current = "nonValue";
  String location_gps = "nonValue";
  String location_detail = "nonValue";
  String name_store = "nonValue";
  String location_store = "nonValue";
  String detail_store = "nonValue";
  String credit_number = "nonValue";
  String counter_service = "nonValue";
  String back_number = "nonValue";
  String qr_code = "nonValue";
  String alipay = "nonValue";
  String paypal = "nonValue";
  String cryptocurrency = "nonValue";
  String role_detail = "nonValue";
  String work_id = "1";
  String price = "99";
  String work_chat_detail = "nonValue";
  String work_image_detail = "nonValue";
  String order_q_job = "1";
  String status_finish_job = "nonValue";
  String date_receive_customer = "1999-05-13";
  String data_sent_customer = "nonValue";
  String data_type_user = "technician";

  String nawJsonSelect = "jsonSelectData";

/// set data in class////
  setEmail(String email){
    this.email = email;
  }
  setId(String id){
    this.id = id;
  }

  setPassword(String password){
    this.password = password;
  }
  setIdRole(String id_role){
    this.id_role = id_role;
  }
  setAppleId(String appleId){
    this.apple_id = appleId;
  }
  setPhoneNumber(String phoneNumber){
    this.phone_number = phoneNumber;
  }
  setSocialNetwork(String socialNetwork){
    this.social_network = socialNetwork;
  }
  setIdData(String idData){
    this.id_data = idData;
  }
  setFirstName(String firstName){
    this.first_name = firstName;
  }
  setLastName(String lastName){
    this.last_name = lastName;
  }
  setBirthday(String birthday){
    this.birthday = birthday;
  }
  setGender(String gender){
    this.gender = gender;
  }
  setNickname(String nickname){
    this.nickname = nickname;
  }
  setEducation(String education){
    this.education = education;
  }
  setCampaignUse(String campaignUse){
    this.campaign_use = campaignUse;
  }
  setfavouriteColor(String favouriteColor){
    this.favourite_color = favouriteColor;
  }
  setNumberCarDoor(String numberCarDoor){
    this.number_car_door = number_car_door;
  }
  setCarType(String carType){
    this.car_type = carType;
  }
  setAgeChildren(String ageChildren){
    this.age_children = ageChildren;
  }
  setMaritalStatus(String maritalStatus){
    this.marital_status =maritalStatus;
  }
  setEnterpire(String enterpire){
    this.enterpire = enterpire;
  }
  setPetOwner(String petOwner){
    this.pet_ownership = petOwner;
  }
  setAge(String age){
    this.age = age;
  }
  setPropertyType(String propertyType){
    this.property_type = propertyType;
  }
  setEthnicity(String ethnicity){
    this.ethnicity = ethnicity;
  }
  setNumberChildren(String numberChildren){
    this.number_children = numberChildren;
  }
  setLocationQpsCurrent(String locationQpsCurrent){
    this.location_qps_current = locationQpsCurrent;
  }
  setLocationGps(String locationGps){
    this.location_gps = locationGps;
  }
  setLocationDetail(String locationDetail){
    this.location_detail = locationDetail;
  }
  setNameStore(String nameStore){
    this.name_store = nameStore;
  }
  setLocationStore(String locationStore){
    this.location_store = locationStore;
  }

  setDetailStore(String detailStore){
    this.detail_store = detailStore;
  }

  setCreditNumber(String creditNumber){
    this.credit_number = creditNumber;
  }

  setCounterService(String counterService){
    this.counter_service = counterService;
  }

  setBackNumber(String backNumber){
    this.back_number = backNumber;
  }
  setQrCode(String qrCode){
    this.qr_code =qrCode;
  }
  setAlipay(String alipay){
    this.alipay = alipay;
  }
  setPaypal(String paypal){
    this.paypal = paypal;
  }
  setCryptocurrency(String crypto){
    this.cryptocurrency = crypto;
  }
  setRoleDetail(String roleDetail){
    this.role_detail = roleDetail;
  }
  setWorkId(String workId){
    this.work_id = workId;
  }
  setPrice(String price){
    this.price = price;
  }

  setWorkChatDetail(String workChatDetail){
    this.work_chat_detail = workChatDetail;
  }

  setWorkImageDetail(String workImageDetail){
    this.work_image_detail = workImageDetail;
  }
  setOrderQJob(String orderQJob){
    this.order_q_job = orderQJob;
  }
  setStatusFinishJob(String statusFinishJob){
    this.status_finish_job = statusFinishJob;
  }
  setDataReceiveCustomer(String dataReceiveCustomer){
    this.date_receive_customer = dataReceiveCustomer;
  }
  sentDataSentCustomer(String dataSentCustomer){
    this.data_sent_customer =  dataSentCustomer;
  }
  sentDataTypeUser(String typeUser){
    this.data_type_user = typeUser;
  }

  set_content(String textContent){ // set content
    _content = textContent;
  }
  String get_content(){ // return content
    return _content;
  }
  set_nameJson(String textNameJson){ // set nameJson
    nameJson = textNameJson;
  }
  String get_nameJson(){ // get nameJson
    return nameJson;
  }
  String get_nameJsonSelect(){ // get nameJson
    return nawJsonSelect;
  }
  setNameLocalHost(String name){// set nameLocalhost
    nameLocalHost = name;
  }
  // Find the Documents path
  Future<String> _getDirPath() async { // get  documents path
    final _dir = await getApplicationDocumentsDirectory();
    print(_dir);
    return _dir.path;
  }
  getDirPathText(){//  print get dir path
    print(_getDirPath());
  }
  Future<void> _writeData(String textFile) async { //future write data json
    final _dirPath = await _getDirPath();
    final _myFile = File('$_dirPath/$nameJson.json');
    // If data.txt doesn't exist, it will be created automatically

    await _myFile.writeAsString(textFile);
  }

  writeDataInput(String text){//future write data
    _writeData(text);
  }
  writeDataInputClear(){ // clear json file
    _writeData("");
  }

  Future<void> _writeDataSelect(String textFile) async { //future write data json
    final _dirPath = await _getDirPath();
    final _myFile = File('$_dirPath/$nawJsonSelect.json');
    // If data.txt doesn't exist, it will be created automatically

    await _myFile.writeAsString(textFile);
  }


  Future<void> printFutureHello() async { // print future  hello
    print(await http.read(Uri.parse('http://$nameLocalHost/hello.php')));
  }

  printPHPHello(){ // print PHP hello
    printFutureHello();
  }

  Future<void> printFutureConnection() async { //print future  connection
    print(await http.read(Uri.parse('http://$nameLocalHost/connection.php')));
  }

  printPHPConnection(){// print PHP connection
    printFutureConnection();
  }

  Future<String> printFutureSelect_db() async { //print future  select_db //return string select_db
      String textData = await http.read(Uri.parse('http://$nameLocalHost/select_db.php'));
      print(textData);
      return textData;
  }

  Future<void> writeJsonEmail() async { //show email and write to json
    print("writeJsonSelect_db");
    email = await http.read(Uri.parse('http://$nameLocalHost/$folderLocalHost/select_db_email.php'));
    print(email);
    writeJson();
    //writeDataInput(email);
  }

  writeJson(){//write Json file
    String textForm = '{ "id":$id, "email":$email,"password":$password,"id_role":$id_role,"apple_id":$apple_id'
        ',"phone_number":$phone_number,"social_network":$social_network,"id_data":$id_data,'
        '"first_name":$first_name, "last_name":$last_name,"birthday":$birthday,"gender":$gender,"nickname":$nickname,'
        '"education":$education, "campaign_use":$campaign_use,"favourite_color":$favourite_color,"number_car_door":$number_car_door,'
        '"car_type":$car_type},"age_children":$age_children,"marital_status":$marital_status,"enterpire":$enterpire,"pet_ownership":$pet_ownership,'
        '"age":$age,"property_type":$property_type, "ethnicity":$ethnicity,"number_children":$number_children,"location_qps_current":$location_qps_current,'
        '"location_gps":$location_gps,"location_detail":$location_detail, "name_store":$name_store,"location_store":$location_store,"detail_store":$detail_store,'
        '"credit_number":$credit_number, "counter_service":$counter_service, "back_number":$back_number,"qr_code":$qr_code,"alipay":$alipay,"paypal":$paypal,'
        '"cryptocurrency":$cryptocurrency, " role_detail":$role_detail,"work_id":$work_id,"price":$price,"work_chat_detail":$work_chat_detail,"work_image_detail":$work_image_detail,'
        ' " order_q_job":$order_q_job,"status_finish_job":$status_finish_job,"data_receive_customer":$date_receive_customer,"data_sent_customer":$data_sent_customer}';
    _writeData(textForm);
  }


  //use email and password to find id
  Future<String> findFutureIdAndSetId(String email,String password) async{

    var url = 'http://$nameLocalHost/$folderLocalHost/find_id_with_email_password.php';// link file php

    // Store all data with Param Name.
    var data = {'email': email, 'password' : password};

    // Starting Web API Call.
    var response = await http.post(Uri.parse(url), body: json.encode(data));
    //print(await http.read(Uri.parse(url)));
    var textMessage = response.body;
    String text = textMessage;// set string text
    //id = text;// set id in class
    setId(text);
    //print("id :: "+id);

    //print("=====");
    //print(text);
    return text;// return value id
  }

  //delete record MySql
  Future<void> DeleteFutureFromMySql(String id,String table) async{

    var url = 'http://$nameLocalHost/$folderLocalHost/deleteDataMySql.php';// link file php
    //print(await http.read(Uri.parse(url)));


    // Store all data with Param Name.
    var data = {'id': id, 'table' : table};

    // Starting Web API Call.
    var response = await http.post(Uri.parse(url), body: json.encode(data));
    //print(await http.read(Uri.parse(url)));
    var textMessage = response.body;
    String text = textMessage;// set string text
    //id = text;// set id in class
    //setId(text);
    //print("id :: "+id);

    //print("=====");
    print(text);
    //return text;// return value id
  }


  // Update data MYSql
  Future<void> UpdataFutureFromMySql(String id,String table,String DataType,String DataValue) async{

    var url = 'http://$nameLocalHost/$folderLocalHost/UpdateDataMySql.php';// link file php

    // Store all data with Param Name.
    var data = {'id': id, 'table' : table,'DataType':DataType,'DataValue':DataValue};

    // Starting Web API Call.
    var response = await http.post(Uri.parse(url), body: json.encode(data));
    //print(await http.read(Uri.parse(url)));
    var textMessage = response.body;
    String text = textMessage;// set string text
    //id = text;// set id in class
    //setId(text);
    //print("id :: "+id);

    //print("=====");
    print(text);
    //return text;// return value id
  }

  // show all data with Id
  Future<void> findFutureAllDataWithIdAndWriteJson(String id,String typeUser) async{

    if(id != "nonValue") {
      //if (typeUser == "customer") {
        //print(1);
        var url = 'http://$nameLocalHost/$folderLocalHost/showAllDataWithId.php';// link file php

        // Store all data with Param Name.
        var data = {'id': id,'typeUser':typeUser};

        // Starting Web API Call.
        var response = await http.post(Uri.parse(url), body: json.encode(data));
        //print(await http.read(Uri.parse(url)));
        var textMessage = response.body;
        String text = textMessage;// set string text
        print(text);
        _writeData(text);
        //id = text;// set id in class

    }else{
      print("nonValue id");
    }
  }

  // Set data with email and password
  findIdAndSetId(String email,String password) async {
    String key = await findFutureIdAndSetId(email,password) as String;
    setId(key);
  }
  // return Id
  returnId(){
    return id;
  }
  //Use data to get all data
  setIdToGetData(String email,String password,String typeUser) async{
    String key = await findFutureIdAndSetId(email,password) as String;
    //print("key :: "+key);
    findFutureAllDataWithIdAndWriteJson(key,typeUser);
  }

  // encrypt password
  String encryptPassword(String password){
    return md5.convert(utf8.encode(password)).toString();;
  }

  // send all data to php
  Future<void> sendFuturePHP() async{

    var url = 'http://$nameLocalHost/$folderLocalHost/sendAllData.php';// link file php
    //print(await http.read(Uri.parse(url)));

    // Store all data with Param Name.
    var data = {'id': id,'email': email, 'password' : password,'id_role': id_role,'apple_id' : apple_id,
    'phone_number': phone_number,
    'social_network' : social_network,
    'id_data' : id_data,
    'first_name' : first_name,
    'last_name' : last_name,
    'birthday' : birthday,// careful
    'gender' : gender,

    'nickname' : nickname,
    'education' : education,
    'campaign_use' : campaign_use,
    'favourite_color' : favourite_color,
    'number_car_door' : number_car_door,
    'car_type' : car_type,

    'age_children' : age_children,
    'marital_status' : marital_status,
    'enterpire' : enterpire,
    'pet_ownership' : pet_ownership,
    'age' : age,
    'property_type' : property_type,
    'ethnicity' : ethnicity,
    'number_children' : number_children,
    'location_qps_current' : location_qps_current,

    'location_gps' : location_gps,
    'location_detail' : location_detail,
    'name_store' : name_store,
    'location_store' : location_store,
    'detail_store' : detail_store,
    'credit_number' : credit_number,
    'counter_service' : counter_service,
    'back_number' : back_number,
    'qr_code' : qr_code,

    'alipay' : alipay,
    'paypal' : paypal,
    'cryptocurrency' : cryptocurrency,
    'role_detail' : role_detail,
    'work_id' : work_id,
    'price' : price,
    'work_chat_detail' : work_chat_detail,
    'work_image_detail' : work_image_detail,
    'order_q_job' : order_q_job,

    'status_finish_job' :  status_finish_job,
    'data_receive_customer' : date_receive_customer,
    'data_sent_customer' : data_sent_customer,
    'typeUser': data_type_user,
    };

    // Starting Web API Call.
    var response = await http.post(Uri.parse(url), body: json.encode(data));
    //print(await http.read(Uri.parse(url)));
    var textMessage = response.body;
    String text = textMessage;// set string text
    print(text);
    //id = text;// set id in class
    //print("id :: "+id);
    //print("=====");
    //print(text);
    //return text;// return value id
  }



  //=======CRUD========Create, read, update and delete===============

  Future<void> setDeleteDataMySql(String tableName,String typeName,String valueName ) async{
    var url = 'http://$nameLocalHost/$folderLocalHost/deleteDataMySql1.php';//
    var data = {'tableName':tableName,'typeName':typeName,'valueName':valueName};
    var response = await http.post(Uri.parse(url), body: json.encode(data));
    var textMessage = response.body;
    String text = textMessage;// set string text
    //print(text);
  }
  Future<void> setUpdateDataMySql(String tableName,String typeName,String valueName,String typeCondition,String valueCondition) async{
    var url = 'http://$nameLocalHost/$folderLocalHost/UpdateDataMySql1.php';//
    //print(await http.read(Uri.parse(url)));
    var data = {'table':tableName,'dataType':typeName,'dataValue':valueName,'dataTypeCondtion':typeCondition,'valueConditon':valueCondition};
    var response = await http.post(Uri.parse(url), body: json.encode(data));
    var textMessage = response.body;
    String text = textMessage;// set string text
    print(text);
  }



  //String ansSelect = "fuck";
  Future<String> setSelectDataMySql(String tableName,String selectName,String conditionName,String valueconditonName) async{
    var url = 'http://$nameLocalHost/$folderLocalHost/selectDataMySql.php';
    var data = {'table' : tableName,'selectName':selectName,'conditionName':conditionName,'valueConditionName':valueconditonName};
    var response = await http.post(Uri.parse(url), body: json.encode(data));
    var textMessage = response.body;
    String text = textMessage;// set string text
    setAnsSelect(text);
    _writeDataSelect(text);
    //print("ansSelect $ansSelect");
    print(text);
    return text;
  }

  setAnsSelect(String key){
    //ansSelect = key;
  }

  Future<void> insertUserTable(String id,String firstname,String lastname,String type,String address,String phone,String user,String password,String avatar,String lat,String lng) async{
    var url = 'http://$nameLocalHost/$folderLocalHost/insertUserTable.php';
    var data = {'id' : id,'firstname':firstname,'lastname': lastname,'type': type,'address': address,
    'phone': phone,'user': user,'password': password,'avatar': avatar,'lat': lat,'lng': lng};
    var response = await http.post(Uri.parse(url), body: json.encode(data));
    var textMessage = response.body;
    String text = textMessage;// set string text
    print(text);
  }

  Future<void> insertSubmitService_customerTable(String id,String firstname,String lastname,String phone,String selectTimeDate,String typeTechnician,String detail,String images,String address,String lat,String lng) async{
    var url = 'http://$nameLocalHost/$folderLocalHost/insertSubmitServiceCustomer.php';
    var data = {'id' : id,'firstname':firstname,'lastname': lastname,'phone': phone,'select_time_date': selectTimeDate,
      'type_technician': typeTechnician, 'detail': detail,'images': images,'address': address,'lat': lat,'lng': lng};
    var response = await http.post(Uri.parse(url), body: json.encode(data));
    var textMessage = response.body;
    String text = textMessage;// set string text
    print(text);
  }

}