package com.example.projec1234

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
